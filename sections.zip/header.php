<!-- ======== header section ======== -->

	<style>

		/* ======== styles for header ======== */

		header {
			background-color: #ddd;
			padding: 10px 0;
		}

		header .tagline h5 {
			text-align: right;
		}

	</style>

	</head>

	<header>
		<div class="row">
			<div class="small-6 large-6 columns">
				<img src="#" alt="site logo" class="c-input" />
			</div><!-- /small-6 large-6 columns -->
			<div class="small-6 large-6 columns tagline">
				<h5 class="c-input">Ad Supported Site Tagline</h5>
			</div><!-- /small-6 large-6 columns -->
		</div><!-- /row -->
	</header>