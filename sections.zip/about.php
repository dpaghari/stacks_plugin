<!-- ======== about section ======== -->

	<style>

		/* ======== styles for about ======== */

		#about {
			background-color: #eee;
			padding: 75px 0;
		}

		#about h2 {
			margin-bottom: 25px;
		}

		#about img {
		 	margin-bottom: 25px;
		 }
		
	</style>

	<div id="about">
		<div class="row">
			<div class="small-12 medium-6 large-6 columns">
                 <img src="img/placeholder.jpg" alt="placeholder" class="c-input" />
			</div><!-- /columns -->
			<div class="small-12 medium-6 large-6 columns">
				<h2 class="c-input">About Product Name</h2>
				<p class="c-input">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
				<a href="#" class="cta c-input">Download Now Text CTA</a>
			</div><!-- /columns -->
		</div><!-- /row -->
	</div><!-- /about -->