<!-- ======== screenshots section ======== -->

	<style>

		/* ======== styles for screenshots ======== */

		#screenshots {
			background-color: #fff;
			padding: 75px 0;
		}

		#screenshots h2 {
			margin-bottom: 25px;
			text-align: center;
		}

		#screenshots .columns {
			padding: 0.9375rem;
		}
		
	</style>

	<div id="screenshots">
		<div class="row">
			<h2 class="c-input">Screenshots Headline</h2>
		</div><!-- /row -->
		<div class="row">
			<div class="small-12 medium-4 large-4 columns">
				<img src="img/placeholder.jpg" alt="placeholder" class="c-input" />
			</div><!-- /columns -->
			<div class="small-12 medium-4 large-4 columns">
				<img src="img/placeholder.jpg" alt="placeholder" class="c-input" />
			</div><!-- /columns -->
			<div class="small-12 medium-4 large-4 columns">
				<img src="img/placeholder.jpg" alt="placeholder" class="c-input" />
			</div><!-- /columns -->
		</div><!-- /row -->
		<div class="row">
			<div class="small-12 medium-4 large-4 columns">
				<img src="img/placeholder.jpg" alt="placeholder" class="c-input" />
			</div><!-- /columns -->
			<div class="small-12 medium-4 large-4 columns">
				<img src="img/placeholder.jpg" alt="placeholder" class="c-input" />
			</div><!-- /columns -->
			<div class="small-12 medium-4 large-4 columns">
				<img src="img/placeholder.jpg" alt="placeholder" class="c-input" />
			</div><!-- /columns -->
		</div><!-- /row -->
	</div><!-- /screenshots -->